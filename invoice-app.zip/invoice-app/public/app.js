/* ═══════════════════════════════════════════════════════
   INVOICELENS — app.js
   All frontend logic: upload, AI extraction, dashboard,
   Excel export, Google Drive sync
═══════════════════════════════════════════════════════ */

// ── STATE ────────────────────────────────────────────────
let invoices = JSON.parse(localStorage.getItem('invoicelens_data') || '[]');
let currentExtracted = null;
let dateChartInstance = null;
let vendorChartInstance = null;
let syncInterval = null;
let driveConfig = JSON.parse(localStorage.getItem('invoicelens_drive') || 'null');

// ── NAVIGATION ────────────────────────────────────────────
function showView(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(`view-${view}`).classList.add('active');
  document.querySelector(`[data-view="${view}"]`).classList.add('active');

  const titles = {
    upload: ['Upload Invoice', 'Scan & extract expense data instantly'],
    dashboard: ['Dashboard', 'Expense analytics & insights'],
    invoices: ['All Invoices', `${invoices.length} invoice${invoices.length !== 1 ? 's' : ''} recorded`],
  };
  document.getElementById('pageTitle').textContent = titles[view][0];
  document.getElementById('pageSub').textContent = titles[view][1];

  if (view === 'dashboard') renderDashboard();
  if (view === 'invoices') renderInvoiceTable(invoices);
}

// ── FILE HANDLING ─────────────────────────────────────────
function handleDragOver(e) {
  e.preventDefault();
  document.getElementById('dropZone').classList.add('drag-over');
}
function handleDragLeave() {
  document.getElementById('dropZone').classList.remove('drag-over');
}
function handleDrop(e) {
  e.preventDefault();
  document.getElementById('dropZone').classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) processFile(file);
}
function handleFileSelect(e) {
  const file = e.target.files[0];
  if (file) processFile(file);
  e.target.value = '';
}

async function processFile(file) {
  const allowed = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
  if (!allowed.includes(file.type)) {
    showToast('Please upload JPG, PNG or PDF files only', 'error');
    return;
  }
  if (file.size > 20 * 1024 * 1024) {
    showToast('File too large (max 20MB)', 'error');
    return;
  }

  // Show processing state
  document.getElementById('resultsEmpty').style.display = 'none';
  document.getElementById('processingState').style.display = 'flex';
  document.getElementById('invoiceResults').style.display = 'none';

  const steps = ['Reading document…', 'Identifying vendor…', 'Extracting line items…', 'Calculating totals…', 'Finalizing…'];
  let stepIdx = 0;
  const stepInterval = setInterval(() => {
    if (stepIdx < steps.length) {
      document.getElementById('processingStep').textContent = steps[stepIdx++];
    }
  }, 800);

  try {
    // Convert file to base64
    const base64 = await fileToBase64(file);
    const mediaType = file.type === 'application/pdf' ? 'application/pdf' : file.type;

    // Call Netlify function
    const resp = await fetch('/.netlify/functions/extract-invoice', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ base64, mediaType, filename: file.name }),
    });

    clearInterval(stepInterval);

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err.error || `Server error ${resp.status}`);
    }

    const data = await resp.json();
    currentExtracted = { ...data, id: Date.now(), uploadedAt: new Date().toISOString() };
    renderResults(currentExtracted);

  } catch (err) {
    clearInterval(stepInterval);
    document.getElementById('processingState').style.display = 'none';
    document.getElementById('resultsEmpty').style.display = 'flex';
    showToast('Error: ' + err.message, 'error');
    console.error(err);
  }
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ── RENDER EXTRACTED RESULTS ──────────────────────────────
function renderResults(data) {
  document.getElementById('processingState').style.display = 'none';
  document.getElementById('invoiceResults').style.display = 'block';

  document.getElementById('r-vendor').textContent   = data.vendor || 'Unknown Vendor';
  document.getElementById('r-date').textContent     = data.date   || '—';
  document.getElementById('r-total').textContent    = formatCurrency(data.total);
  document.getElementById('r-invnum').textContent   = data.invoiceNumber || '—';
  document.getElementById('r-category').textContent = data.category || '—';
  document.getElementById('r-tax').textContent      = data.tax ? formatCurrency(data.tax) : '—';
  document.getElementById('r-payment').textContent  = data.paymentMethod || '—';

  const body = document.getElementById('lineItemsBody');
  body.innerHTML = '';
  const items = Array.isArray(data.lineItems) ? data.lineItems : [];
  if (items.length === 0) {
    body.innerHTML = '<div class="line-item-row" style="grid-template-columns:1fr;color:var(--text-muted);font-size:0.8rem;">No line items extracted</div>';
  } else {
    items.forEach(item => {
      const row = document.createElement('div');
      row.className = 'line-item-row';
      row.innerHTML = `
        <span>${item.description || '—'}</span>
        <span>${item.quantity != null ? item.quantity : '—'}</span>
        <span>${item.unitPrice != null ? formatCurrency(item.unitPrice) : '—'}</span>
        <span>${formatCurrency(item.total || (item.unitPrice * item.quantity) || 0)}</span>
      `;
      body.appendChild(row);
    });
  }
}

// ── SAVE INVOICE ──────────────────────────────────────────
function saveInvoice() {
  if (!currentExtracted) return;
  invoices.unshift(currentExtracted);
  persist();
  showToast('Invoice saved!', 'success');
  resetUpload();
  scheduleSync();
}

function resetUpload() {
  currentExtracted = null;
  document.getElementById('resultsEmpty').style.display = 'flex';
  document.getElementById('invoiceResults').style.display = 'none';
  document.getElementById('processingState').style.display = 'none';
}

// ── DASHBOARD ─────────────────────────────────────────────
function renderDashboard() {
  // KPIs
  const total = invoices.reduce((s, inv) => s + (parseFloat(inv.total) || 0), 0);
  const now = new Date();
  const monthInvs = invoices.filter(inv => {
    const d = new Date(inv.date || inv.uploadedAt);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });
  const monthTotal = monthInvs.reduce((s, inv) => s + (parseFloat(inv.total) || 0), 0);
  const avg = invoices.length ? total / invoices.length : 0;

  // Top vendor
  const vendorMap = {};
  invoices.forEach(inv => {
    const v = inv.vendor || 'Unknown';
    vendorMap[v] = (vendorMap[v] || 0) + (parseFloat(inv.total) || 0);
  });
  const topVendor = Object.entries(vendorMap).sort((a,b) => b[1]-a[1])[0];

  document.getElementById('kpi-total').textContent     = formatCurrency(total);
  document.getElementById('kpi-total-sub').textContent = `${invoices.length} invoice${invoices.length!==1?'s':''}`;
  document.getElementById('kpi-month').textContent     = formatCurrency(monthTotal);
  document.getElementById('kpi-month-sub').textContent = now.toLocaleString('en', {month:'long', year:'numeric'});
  document.getElementById('kpi-vendor').textContent    = topVendor ? topVendor[0] : '—';
  document.getElementById('kpi-vendor-sub').textContent = topVendor ? formatCurrency(topVendor[1]) : '—';
  document.getElementById('kpi-avg').textContent       = formatCurrency(avg);

  renderDateChart(30);
  renderVendorChart(8);
  renderCategoryBars();
}

function renderDateChart(days) {
  const ctx = document.getElementById('dateChart').getContext('2d');
  if (dateChartInstance) dateChartInstance.destroy();

  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - parseInt(days));
  const filtered = invoices.filter(inv => new Date(inv.date || inv.uploadedAt) >= cutoff);

  // Group by date
  const groups = {};
  filtered.forEach(inv => {
    const d = (inv.date || inv.uploadedAt || '').split('T')[0];
    if (d) groups[d] = (groups[d] || 0) + (parseFloat(inv.total) || 0);
  });
  const sorted = Object.entries(groups).sort((a,b) => a[0].localeCompare(b[0]));
  const labels = sorted.map(([d]) => {
    const dt = new Date(d + 'T00:00:00');
    return dt.toLocaleDateString('en', {month:'short', day:'numeric'});
  });
  const vals = sorted.map(([,v]) => v);

  dateChartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data: vals,
        backgroundColor: 'rgba(232,166,80,0.7)',
        borderColor: 'rgba(232,166,80,1)',
        borderWidth: 1,
        borderRadius: 4,
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => formatCurrency(c.raw) } } },
      scales: {
        x: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#9a9490', font: { family: 'DM Mono', size: 10 } } },
        y: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#9a9490', font: { family: 'DM Mono', size: 10 }, callback: v => '$'+v.toLocaleString() } }
      }
    }
  });
}

function renderVendorChart(topN) {
  const ctx = document.getElementById('vendorChart').getContext('2d');
  if (vendorChartInstance) vendorChartInstance.destroy();

  const vendorMap = {};
  invoices.forEach(inv => {
    const v = inv.vendor || 'Unknown';
    vendorMap[v] = (vendorMap[v] || 0) + (parseFloat(inv.total) || 0);
  });
  const sorted = Object.entries(vendorMap).sort((a,b)=>b[1]-a[1]).slice(0, topN);

  const palette = ['#e8a650','#f0b86a','#d4903e','#f5c87c','#c17a2e','#eda660','#e89040','#d4803a'];

  vendorChartInstance = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: sorted.map(([v]) => v),
      datasets: [{
        data: sorted.map(([,a]) => a),
        backgroundColor: sorted.map((_,i) => palette[i % palette.length]),
        borderColor: '#161616',
        borderWidth: 2,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: 'right', labels: { color: '#9a9490', font: { family: 'DM Sans', size: 11 }, boxWidth: 12, padding: 8 } },
        tooltip: { callbacks: { label: c => ` ${c.label}: ${formatCurrency(c.raw)}` } }
      }
    }
  });
}

function renderCategoryBars() {
  const catMap = {};
  invoices.forEach(inv => {
    const cat = inv.category || 'Uncategorized';
    catMap[cat] = (catMap[cat] || 0) + (parseFloat(inv.total) || 0);
  });
  const sorted = Object.entries(catMap).sort((a,b)=>b[1]-a[1]);
  const max = sorted.length ? sorted[0][1] : 1;

  const container = document.getElementById('categoryBars');
  container.innerHTML = sorted.length ? '' : '<p style="color:var(--text-muted);font-size:.85rem;padding:12px 0">No data yet.</p>';
  sorted.forEach(([cat, amt]) => {
    const pct = (amt / max * 100).toFixed(1);
    const row = document.createElement('div');
    row.className = 'cat-bar-row';
    row.innerHTML = `
      <span class="cat-bar-label" title="${cat}">${cat}</span>
      <div class="cat-bar-track"><div class="cat-bar-fill" style="width:${pct}%"></div></div>
      <span class="cat-bar-amt">${formatCurrency(amt)}</span>
    `;
    container.appendChild(row);
  });
}

// ── INVOICE TABLE ─────────────────────────────────────────
let filteredInvoices = [...invoices];
let sortState = { col: 'date', dir: -1 };
let filterSearch = '';
let filterDate = 'all';
let filterCategory = 'all';

function renderInvoiceTable(data) {
  const tbody = document.getElementById('invoiceTableBody');
  if (!data.length) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="6">No invoices found.</td></tr>';
    return;
  }
  tbody.innerHTML = data.map(inv => `
    <tr>
      <td>${formatDate(inv.date || inv.uploadedAt)}</td>
      <td class="td-vendor">${esc(inv.vendor || '—')}</td>
      <td style="font-family:var(--font-mono);font-size:0.78rem">${esc(inv.invoiceNumber || '—')}</td>
      <td><span class="cat-badge">${esc(inv.category || 'General')}</span></td>
      <td class="td-amount">${formatCurrency(inv.total)}</td>
      <td style="display:flex;gap:6px">
        <button class="btn-view-sm" onclick="openInvoiceModal(${inv.id})">View</button>
        <button class="btn-del-sm" onclick="deleteInvoice(${inv.id})" title="Delete">🗑</button>
      </td>
    </tr>
  `).join('');

  // Populate category filter
  const cats = [...new Set(invoices.map(inv => inv.category || 'General'))];
  const cf = document.getElementById('categoryFilter');
  const current = cf.value;
  cf.innerHTML = '<option value="all">All categories</option>' + cats.map(c => `<option value="${c}" ${c===current?'selected':''}>${c}</option>`).join('');
}

function filterInvoices(search) {
  filterSearch = search.toLowerCase();
  applyFilters();
}
function filterByDate(days) {
  filterDate = days;
  applyFilters();
}
function filterByCategory(cat) {
  filterCategory = cat;
  applyFilters();
}
function applyFilters() {
  let data = [...invoices];
  if (filterSearch) data = data.filter(inv =>
    (inv.vendor||'').toLowerCase().includes(filterSearch) ||
    (inv.invoiceNumber||'').toLowerCase().includes(filterSearch)
  );
  if (filterDate !== 'all') {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - parseInt(filterDate));
    data = data.filter(inv => new Date(inv.date || inv.uploadedAt) >= cutoff);
  }
  if (filterCategory !== 'all') data = data.filter(inv => (inv.category||'General') === filterCategory);
  filteredInvoices = data;
  renderInvoiceTable(data);
}

function sortBy(col) {
  if (sortState.col === col) sortState.dir *= -1;
  else { sortState.col = col; sortState.dir = -1; }
  filteredInvoices.sort((a, b) => {
    let av = col === 'total' ? parseFloat(a.total)||0 : (a[col]||'');
    let bv = col === 'total' ? parseFloat(b.total)||0 : (b[col]||'');
    return av > bv ? sortState.dir : av < bv ? -sortState.dir : 0;
  });
  renderInvoiceTable(filteredInvoices);
}

function deleteInvoice(id) {
  if (!confirm('Delete this invoice?')) return;
  invoices = invoices.filter(inv => inv.id !== id);
  persist();
  applyFilters();
  showToast('Invoice deleted', 'success');
}

function openInvoiceModal(id) {
  const inv = invoices.find(i => i.id === id);
  if (!inv) return;
  const items = Array.isArray(inv.lineItems) ? inv.lineItems : [];
  document.getElementById('modalContent').innerHTML = `
    <h2 style="font-family:var(--font-display);font-size:1.3rem;margin-bottom:4px">${esc(inv.vendor||'Unknown')}</h2>
    <p style="color:var(--text-muted);font-size:0.85rem;margin-bottom:20px">${formatDate(inv.date||inv.uploadedAt)} · Invoice #${esc(inv.invoiceNumber||'—')}</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px">
      ${metaBox('Total', formatCurrency(inv.total))}
      ${metaBox('Category', inv.category||'—')}
      ${metaBox('Tax', inv.tax ? formatCurrency(inv.tax) : '—')}
      ${metaBox('Payment', inv.paymentMethod||'—')}
    </div>
    <h4 style="font-size:.75rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.8px;margin-bottom:8px">Line Items</h4>
    <div class="line-items-table">
      <div class="line-items-head"><span>Description</span><span>Qty</span><span>Unit</span><span>Total</span></div>
      ${items.map(it => `<div class="line-item-row"><span>${esc(it.description||'—')}</span><span>${it.quantity??'—'}</span><span>${it.unitPrice!=null?formatCurrency(it.unitPrice):'—'}</span><span>${formatCurrency(it.total||(it.unitPrice*it.quantity)||0)}</span></div>`).join('') || '<div class="line-item-row" style="grid-template-columns:1fr;color:var(--text-muted)">No line items</div>'}
    </div>
    ${inv.notes ? `<p style="margin-top:16px;font-size:.82rem;color:var(--text-muted);line-height:1.5"><strong style="color:var(--text-sub)">Notes:</strong> ${esc(inv.notes)}</p>` : ''}
  `;
  document.getElementById('modalOverlay').style.display = 'flex';
}
function metaBox(label, val) {
  return `<div class="meta-item"><span class="meta-label">${label}</span><span class="meta-value">${val}</span></div>`;
}
function closeModal() { document.getElementById('modalOverlay').style.display = 'none'; }

// ── EXCEL EXPORT ──────────────────────────────────────────
function exportToExcel() {
  if (!invoices.length) { showToast('No invoices to export', 'error'); return; }

  const wb = XLSX.utils.book_new();

  // Summary sheet
  const summaryData = [
    ['InvoiceLens — Expense Report', '', '', '', ''],
    ['Generated:', new Date().toLocaleString(), '', '', ''],
    ['', '', '', '', ''],
    ['DATE', 'VENDOR', 'INVOICE #', 'CATEGORY', 'TAX', 'TOTAL'],
    ...invoices.map(inv => [
      formatDate(inv.date || inv.uploadedAt),
      inv.vendor || '',
      inv.invoiceNumber || '',
      inv.category || '',
      parseFloat(inv.tax) || 0,
      parseFloat(inv.total) || 0,
    ]),
    ['', '', '', '', 'GRAND TOTAL:', invoices.reduce((s, inv) => s + (parseFloat(inv.total)||0), 0)],
  ];
  const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
  wsSummary['!cols'] = [{ wch: 14 }, { wch: 28 }, { wch: 16 }, { wch: 18 }, { wch: 12 }, { wch: 14 }];
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Summary');

  // Line Items sheet
  const lineData = [
    ['DATE', 'VENDOR', 'INVOICE #', 'ITEM DESCRIPTION', 'QTY', 'UNIT PRICE', 'TOTAL'],
  ];
  invoices.forEach(inv => {
    const items = Array.isArray(inv.lineItems) ? inv.lineItems : [];
    if (items.length === 0) {
      lineData.push([formatDate(inv.date||inv.uploadedAt), inv.vendor||'', inv.invoiceNumber||'', '—', '', '', parseFloat(inv.total)||0]);
    } else {
      items.forEach(item => {
        lineData.push([
          formatDate(inv.date||inv.uploadedAt), inv.vendor||'', inv.invoiceNumber||'',
          item.description||'', item.quantity??'', parseFloat(item.unitPrice)||0,
          parseFloat(item.total||(item.unitPrice*item.quantity))||0,
        ]);
      });
    }
  });
  const wsLines = XLSX.utils.aoa_to_sheet(lineData);
  wsLines['!cols'] = [14,24,14,34,8,12,12].map(w => ({ wch: w }));
  XLSX.utils.book_append_sheet(wb, wsLines, 'Line Items');

  // By Vendor sheet
  const vendorMap = {};
  invoices.forEach(inv => {
    const v = inv.vendor || 'Unknown';
    vendorMap[v] = (vendorMap[v] || 0) + (parseFloat(inv.total)||0);
  });
  const vendorData = [
    ['VENDOR', 'TOTAL EXPENSES', 'INVOICE COUNT'],
    ...Object.entries(vendorMap)
      .sort((a,b)=>b[1]-a[1])
      .map(([v, amt]) => [v, amt, invoices.filter(inv=>(inv.vendor||'Unknown')===v).length]),
  ];
  const wsVendors = XLSX.utils.aoa_to_sheet(vendorData);
  wsVendors['!cols'] = [{ wch: 28 }, { wch: 16 }, { wch: 14 }];
  XLSX.utils.book_append_sheet(wb, wsVendors, 'By Vendor');

  const filename = `InvoiceLens_Export_${new Date().toISOString().split('T')[0]}.xlsx`;
  XLSX.writeFile(wb, filename);
  showToast('Excel file downloaded!', 'success');
}

// ── GOOGLE DRIVE ──────────────────────────────────────────
function connectDrive() {
  document.getElementById('driveModal').style.display = 'flex';
  if (driveConfig) {
    document.getElementById('driveFolderInput').value = driveConfig.folderId || '';
  }
}
function closeDriveModal() {
  document.getElementById('driveModal').style.display = 'none';
}
function saveDriveConfig() {
  const folderId = document.getElementById('driveFolderInput').value.trim();
  const credentials = document.getElementById('driveCredentials').value.trim();
  if (!folderId) { showToast('Please enter a folder ID', 'error'); return; }

  driveConfig = { folderId, hasCredentials: !!credentials };
  localStorage.setItem('invoicelens_drive', JSON.stringify(driveConfig));

  if (credentials) {
    localStorage.setItem('invoicelens_drive_creds', credentials);
  }

  document.getElementById('driveStatus').textContent = '✓ Drive Connected';
  closeDriveModal();
  showToast('Google Drive connected!', 'success');
  startSyncSchedule();
}

function scheduleSync() {
  if (driveConfig) syncToDrive();
}

function startSyncSchedule() {
  if (syncInterval) clearInterval(syncInterval);
  syncInterval = setInterval(syncToDrive, 15 * 60 * 1000);
  syncToDrive();
}

async function syncToDrive() {
  if (!driveConfig) return;
  try {
    const wb = XLSX.utils.book_new();
    const summaryData = [
      ['DATE', 'VENDOR', 'INVOICE #', 'CATEGORY', 'TAX', 'TOTAL'],
      ...invoices.map(inv => [
        formatDate(inv.date || inv.uploadedAt),
        inv.vendor || '',
        inv.invoiceNumber || '',
        inv.category || '',
        parseFloat(inv.tax) || 0,
        parseFloat(inv.total) || 0,
      ]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, ws, 'Invoices');
    const xlsxBuffer = XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });

    const credentials = localStorage.getItem('invoicelens_drive_creds');
    const resp = await fetch('/.netlify/functions/sync-drive', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        folderId: driveConfig.folderId,
        credentials: credentials ? JSON.parse(credentials) : null,
        xlsxBase64: xlsxBuffer,
        filename: `InvoiceLens_${new Date().getFullYear()}.xlsx`,
      }),
    });
    if (resp.ok) {
      const now = new Date().toLocaleTimeString();
      document.getElementById('lastSync').textContent = `Last sync: ${now}`;
      document.getElementById('syncStatus').title = `Synced at ${now}`;
    }
  } catch (e) {
    console.error('Drive sync error:', e);
  }
}

// ── UTILITIES ─────────────────────────────────────────────
function persist() {
  localStorage.setItem('invoicelens_data', JSON.stringify(invoices));
  filteredInvoices = [...invoices];
}
function formatCurrency(val) {
  const n = parseFloat(val);
  if (isNaN(n)) return '$—';
  return n.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
}
function formatDate(str) {
  if (!str) return '—';
  const d = new Date(str);
  if (isNaN(d)) return str;
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}
function esc(str) {
  return String(str||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function showToast(msg, type = '') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = `toast ${type} show`;
  setTimeout(() => toast.className = 'toast', 3000);
}

// ── INIT ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  filteredInvoices = [...invoices];
  if (driveConfig) {
    document.getElementById('driveStatus').textContent = '✓ Drive Connected';
    startSyncSchedule();
  }
});

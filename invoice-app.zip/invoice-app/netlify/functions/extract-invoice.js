// netlify/functions/extract-invoice.js
// Calls Claude API to extract structured data from invoice images/PDFs

const Anthropic = require("@anthropic-ai/sdk");

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON body" }) };
  }

  const { base64, mediaType, filename } = body;
  if (!base64 || !mediaType) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing base64 or mediaType" }) };
  }

  const prompt = `You are an expert invoice data extractor. Analyze this invoice image/document and extract ALL data.

Return ONLY a valid JSON object with this exact structure (no markdown, no explanation):
{
  "vendor": "Company or vendor name",
  "date": "YYYY-MM-DD format if possible, otherwise as shown",
  "invoiceNumber": "invoice or receipt number",
  "category": "one of: Food & Beverage, Supplies, Utilities, Maintenance, Marketing, Payroll, Rent, Insurance, Equipment, Transportation, Professional Services, Other",
  "subtotal": 0.00,
  "tax": 0.00,
  "total": 0.00,
  "paymentMethod": "Cash / Credit Card / Check / Wire Transfer / etc",
  "notes": "any special notes or terms",
  "lineItems": [
    {
      "description": "item description",
      "quantity": 1,
      "unitPrice": 0.00,
      "total": 0.00
    }
  ]
}

Rules:
- All monetary values must be numbers (not strings)
- If a field is not found, use null
- Extract ALL line items visible
- Be as accurate as possible with amounts`;

  try {
    const contentParts = [
      { type: "text", text: prompt },
    ];

    // Attach image or PDF
    if (mediaType === "application/pdf") {
      contentParts.push({
        type: "document",
        source: { type: "base64", media_type: "application/pdf", data: base64 },
      });
    } else {
      contentParts.push({
        type: "image",
        source: { type: "base64", media_type: mediaType, data: base64 },
      });
    }

    const response = await client.messages.create({
      model: "claude-opus-4-6",
      max_tokens: 2000,
      messages: [{ role: "user", content: contentParts }],
    });

    const rawText = response.content
      .filter((c) => c.type === "text")
      .map((c) => c.text)
      .join("");

    // Parse JSON — strip any accidental markdown fences
    const cleaned = rawText.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const extracted = JSON.parse(cleaned);

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(extracted),
    };
  } catch (err) {
    console.error("Extraction error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message || "Extraction failed" }),
    };
  }
};

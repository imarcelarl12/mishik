// netlify/functions/sync-drive.js
// Uploads/updates the Excel file to a Google Drive folder

const { google } = require("googleapis");
const { Readable } = require("stream");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  const { folderId, credentials, xlsxBase64, filename } = body;

  if (!folderId || !xlsxBase64) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing folderId or xlsxBase64" }) };
  }

  // Get credentials from env or request body
  let creds;
  try {
    creds = credentials || JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT || "{}");
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid Google credentials" }) };
  }

  if (!creds.client_email) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Google Service Account credentials not configured" }),
    };
  }

  try {
    const auth = new google.auth.GoogleAuth({
      credentials: creds,
      scopes: ["https://www.googleapis.com/auth/drive"],
    });

    const drive = google.drive({ version: "v3", auth });

    // Check if file already exists in folder
    const search = await drive.files.list({
      q: `'${folderId}' in parents and name='${filename}' and trashed=false`,
      fields: "files(id,name)",
    });

    const buffer = Buffer.from(xlsxBase64, "base64");
    const stream = Readable.from(buffer);

    const mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    if (search.data.files && search.data.files.length > 0) {
      // Update existing file
      const fileId = search.data.files[0].id;
      await drive.files.update({
        fileId,
        media: { mimeType, body: stream },
      });
      return {
        statusCode: 200,
        body: JSON.stringify({ status: "updated", fileId }),
      };
    } else {
      // Create new file
      const created = await drive.files.create({
        requestBody: {
          name: filename,
          parents: [folderId],
          mimeType,
        },
        media: { mimeType, body: stream },
        fields: "id",
      });
      return {
        statusCode: 200,
        body: JSON.stringify({ status: "created", fileId: created.data.id }),
      };
    }
  } catch (err) {
    console.error("Drive sync error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message }),
    };
  }
};
